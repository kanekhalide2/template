=== Baklon ===
Theme Name: Baklon
Theme URI: https://dahz.daffyhazan.com/baklon/
Author: Dahz Theme
Author URI:  http://daffyhazan.com
Description: Baklon is designed for political candidate, political leader, political party and organization. Baklon helps you to reflect your political campaign
Version: 3.2.2
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: baklon
Tags: one-column, two-columns, left-sidebar, right-sidebar, custom-background, custom-colors, featured-images, theme-options


== Description ==

Baklon is designed for political candidate, political leader, political party and organization. Baklon helps you to reflect your political campaign.

== Changelog ==

= 3.2.2 ==
* Update - WpBakery plugin version 6.6.0
* Update - Slider Revolution 6.4.11
* Update - WooCommerce Compatibility template

= 3.2.1 ==
* Update - WpBakery plugin version 6.4.1

= 3.2 ==
* Update - WpBakery plugin version 6.4
* Update - Plugin Core TGMPA
* Compatibility - Woocommerce 4.5.2
* Fix - Metabox Switcher Error
* Fix - Outdated Woocommerce Template


= 3.1 =
* Update - WpBakery plugin version 6.3.
* Update - Slider Revolution plugin version 6.2.22.

= 3.0 = 
* Update Kirki 3.1.5 For Compatibility Wp 5.5
* Compatibility Wordpress 5.5
* Compatibility Woocommerce 4.3.1
* Update Outdated Woocommerce

= 2.1 =
* Released: 01 July 2020
* Compatibility : Wordpress 5.4 and PHP 7.4
* Compatibility : Woocommerce 4.2.2
* Update - Give - Donation Plugin version 2.7.1.
* Update - Smash Balloon Instagram Feed plugin version 2.4.4
* Update - The Events Calendar plugin version 5.1.4.
* Fix - Outdated Woocommerce template.

== Changelog ==
= 2.0 =
* Released: 23 April 2020
* Compatibility : Wordpress 5.4 and PHP 7.4
* Compatibility : Woocommerce 6.1.0
* Update - WpBakery plugin version 6.2.2.
* Update - Slider Revolution plugin version 6.2.2.
* Update - Dahz Extender plugin version 2.0.
* Fix - Split Slider Shorcode
* Fix - Outdated Woocommerce template.
* Fix - Link Team Member Mail.
* Fix - Accordion icon shortcode.


= 1.2.1 =
* Released: 27September 2019
* Fix - Fix Not found Class VC_Edit_Form_Fields


= 1.2.0 =
* Released: 17 September 2019
* Update - update WpBakery plugin version 6.0.5.
* Update - update Slider Revolution plugin version 6.1.1.
* Update - update Dahz Extender plugin version 1.3.0.
* Fix - event shortcode autocomplete on WpBakery shortcodes
* Fix - Fix outdated woocommerce template.
* Fix - Fix ajax megamenu.
* Fix - Fix before after shortcode.
* Fix - Fix accordion icon shortcode.

= 1.1.0 =
* Released: 11 February 2019
* Update - update plugins.
* Fix - header button link
* Fix - responsive options WpBakery vc_column
* Fix - Fix WpBakery frontend editor.
* Fix - Fix outdated woocommerce template.
* Fix - Fix theme transaltions.
* Fix - Fix megamenu mobile parent menu link.
* Fix - Fix responsive hotspot shortcode
* Fix - Fix responsive iframe video popup
* Fix - Fix WpBakery pageable shortcode

