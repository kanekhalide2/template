<a href="<?php echo esc_url( get_permalink() );?>" class="entry-thumbnail">
	<?php echo apply_filters( 'dahz_framework_featured_image_html', $image );?>
</a>