				</div>
				<?php do_action( 'dahz_framework_after_archive_loop' ); ?>
			</div>
			<?php get_sidebar(); ?>
		</div><!-- .uk-grid -->
	</div><!-- .uk-container -->
</div><!-- #de-archive-content -->