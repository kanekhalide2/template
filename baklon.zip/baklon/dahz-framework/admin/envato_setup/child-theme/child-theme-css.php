/*
Theme Name: <?php echo sprintf( '%1$s', $new_theme_title ), "\n"; ?>
Description: This is a child theme for Baklon Theme
Author: Dahz
Template: baklon
Version: 1.0.0
*/

/*************** ADD CUSTOM CSS HERE.   ***************/


@media only screen and (max-width: 48em) {
/*************** ADD MOBILE ONLY CSS HERE  ***************/


}