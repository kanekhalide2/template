<?php
/**
 * The content containing the global wrapper close
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package baklon
 */

?>
			</div>
			<?php do_action( 'dahz_framework_after_main_content' ); ?>
		</div>
		<?php get_sidebar();?>
	</div>
</div>