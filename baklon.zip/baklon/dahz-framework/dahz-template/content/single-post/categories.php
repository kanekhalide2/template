<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package baklon
 */

?>

<div class="entry-categories de-single__entry-categories">
	<?php dahz_framework_post_meta_categories(); ?>
</div>
