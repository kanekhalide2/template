<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package baklon
 */

?>

<div class="entry-meta smaller de-single__entry-meta">
	<?php echo dahz_framework_meta_post(); ?>
</div>
